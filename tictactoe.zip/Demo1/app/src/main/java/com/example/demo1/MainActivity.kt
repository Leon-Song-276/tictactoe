package com.example.demo1

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //create container for the textbox in layout
        val gameResult : TextView = findViewById(R.id.textView2)
        gameResult.text = "turn"
        gameResult.visibility = View.INVISIBLE

        //create container for button in layout
//        val resetButton : Button = findViewById(R.id.button)


        //create container for textview in layout
        //val textView : TextView = findViewById(R.id.textView)

        //create container for imageview in layout

        //(2, 1)
        val imageView8 : ImageView = findViewById(R.id.imageView)
        imageView8.setImageResource(R.drawable.blankframe)

        //(2,2)
        val imageView5 : ImageView = findViewById(R.id.imageView2)
        imageView5.setImageResource(R.drawable.blankframe)

        //(1, 1)
        val imageView7 : ImageView = findViewById(R.id.imageView3)
        imageView7.setImageResource(R.drawable.blankframe)

        //(3, 1)
        val imageView9 : ImageView = findViewById(R.id.imageView4)
        imageView9.setImageResource(R.drawable.blankframe)

        //(3,2)
        val imageView6 : ImageView = findViewById(R.id.imageView5)
        imageView6.setImageResource(R.drawable.blankframe)

        //(1, 2)
        val imageView4 : ImageView = findViewById(R.id.imageView6)
        imageView4.setImageResource(R.drawable.blankframe)

        //(2, 3)
        val imageView2 : ImageView = findViewById(R.id.imageView7)
        imageView2.setImageResource(R.drawable.blankframe)

        //(3, 3)
        val imageView3 : ImageView = findViewById(R.id.imageView8)
        imageView3.setImageResource(R.drawable.blankframe)

        //(1, 3)
        val imageView : ImageView = findViewById(R.id.imageView9)
        imageView.setImageResource(R.drawable.blankframe)

        //decides turn
        var gameTurn = "Cross"
        var turns = 0

        //image that displays the winning icon
        var imageWin : ImageView = findViewById(R.id.imageView11)
        imageWin.visibility = View.INVISIBLE

        //image that will reset everything
        var resetButton : ImageView = findViewById(R.id.imageView10)
        resetButton.setImageResource(R.drawable.resetbutton)

        //variables to lock tiles once clicked
        var lockImage8 = false
        var lockImage5 = false
        var lockImage7 = false
        var lockImage9 = false
        var lockImage6 = false
        var lockImage4 = false
        var lockImage2 = false
        var lockImage3 = false
        var lockImage = false

        //2d array
        val board = Array(3) {
            Array(3) { 0 }
        }

        var winCondition = false
//        gameResult.visibility = View.INVISIBLE
        var turnComplete = false

//        button.setOnClickListener {
//            val currentText : String = editText.text.toString()
//            Log.d("DebugEditText", currentText)
//            textView.text = currentText
//        }

        //changes each image upon clicking
        imageView.setOnClickListener {
            if (!lockImage) {
                if (gameTurn == "Cross") {
                    imageView.setImageResource(R.drawable.crossframe)
                    gameTurn = "Circle"
                    board[0][0] = 1
                } else {
                    imageView.setImageResource(R.drawable.circleframe)
                    gameTurn = "Cross"
                    board[0][0] = 2
                }
                lockImage = true
                turns++
                turnComplete = true
                println("completed turn")
                var i = 0
                while(i < 3) {
                    println("Horizontal Checking")
                    if(board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] != 0) {
                        winCondition = true
                        if(board[i][0] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("horizontal cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[i][1] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("horizontal circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i = 3
                    }else{
                        i++
                    }
                }
                i = 0

                while(i<3) {
                    println("Vertical Checking")
                    if(board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] != 0) {
                        winCondition = true
                        if(board[0][i] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("Vertical Cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[0][i] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("Vertical Circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i=3
                    }else{
                        i++
                    }
                }
                i = 0

                //left cross
                println("Left Cross Checking")
                if (board[0][0] == board[1][1] && board[0][0] == board[2][2] && board [0][0] != 0) {
                    winCondition = true
                    if (board[2][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if(board[2][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                }

                //right cross
                println("Right Cross Checking")
                if (board[0][2] == board[1][1] && board[0][2] == board[2][0] && board [0][2] != 0) {
                    winCondition = true
                    if (board[0][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if (board[0][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }

                }
                if(!winCondition && turns == 9) {
                    println("Draw Game")
                    gameResult.text = "draw"
                    println(gameResult)
                    gameResult.visibility = View.VISIBLE
                    imageWin.setImageResource(R.drawable.blankframe)
                    imageWin.visibility = View.VISIBLE
                }

                if(winCondition) {
                    lockImage = true
                    lockImage2 = true
                    lockImage3 = true
                    lockImage4 = true
                    lockImage5 = true
                    lockImage6 = true
                    lockImage7 = true
                    lockImage8 = true
                    lockImage9 = true
                }
            }
        }

        imageView2.setOnClickListener {
            if (!lockImage2) {
                if (gameTurn == "Cross") {
                    imageView2.setImageResource(R.drawable.crossframe)
                    gameTurn = "Circle"
                    board[0][1] = 1

                } else {
                    imageView2.setImageResource(R.drawable.circleframe)
                    gameTurn = "Cross"
                    board[0][1] = 2
                }
                lockImage2 = true
                turns++
                turnComplete = true
                println("completed turn")
                var i = 0
                while(i < 3) {
                    println("Horizontal Checking")
                    if(board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] != 0) {
                        winCondition = true
                        if(board[i][0] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("horizontal cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[i][1] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("horizontal circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i = 3
                    }else{
                        i++
                    }
                }
                i = 0

                while(i<3) {
                    println("Vertical Checking")
                    if(board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] != 0) {
                        winCondition = true
                        if(board[0][i] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("Vertical Cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[0][i] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("Vertical Circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i=3
                    }else{
                        i++
                    }
                }
                i = 0

                //left cross
                println("Left Cross Checking")
                if (board[0][0] == board[1][1] && board[0][0] == board[2][2] && board [0][0] != 0) {
                    winCondition = true
                    if (board[2][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if(board[2][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                }

                //right cross
                println("Right Cross Checking")
                if (board[0][2] == board[1][1] && board[0][2] == board[2][0] && board [0][2] != 0) {
                    winCondition = true
                    if (board[0][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if (board[0][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }

                }
                if(!winCondition && turns == 9) {
                    println("Draw Game")
                    gameResult.text = "draw"
                    println(gameResult)
                    gameResult.visibility = View.VISIBLE
                    imageWin.setImageResource(R.drawable.blankframe)
                    imageWin.visibility = View.VISIBLE
                }

                if(winCondition) {
                    lockImage = true
                    lockImage2 = true
                    lockImage3 = true
                    lockImage4 = true
                    lockImage5 = true
                    lockImage6 = true
                    lockImage7 = true
                    lockImage8 = true
                    lockImage9 = true
                }
            }
        }


        imageView3.setOnClickListener {
            if (!lockImage3) {
                if (gameTurn == "Cross") {
                    imageView3.setImageResource(R.drawable.crossframe)
                    gameTurn = "Circle"
                    board[0][2] = 1
                } else {
                    imageView3.setImageResource(R.drawable.circleframe)
                    gameTurn = "Cross"
                    board[0][2] = 2
                }
                lockImage3 = true
                turns++
                turnComplete = true
                println("completed turn")
                var i = 0
                while(i < 3) {
                    println("Horizontal Checking")
                    if(board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] != 0) {
                        winCondition = true
                        if(board[i][0] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("horizontal cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[i][1] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("horizontal circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i = 3
                    }else{
                        i++
                    }
                }
                i = 0

                while(i<3) {
                    println("Vertical Checking")
                    if(board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] != 0) {
                        winCondition = true
                        if(board[0][i] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("Vertical Cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[0][i] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("Vertical Circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i=3
                    }else{
                        i++
                    }
                }
                i = 0

                //left cross
                println("Left Cross Checking")
                if (board[0][0] == board[1][1] && board[0][0] == board[2][2] && board [0][0] != 0) {
                    winCondition = true
                    if (board[2][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if(board[2][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                }

                //right cross
                println("Right Cross Checking")
                if (board[0][2] == board[1][1] && board[0][2] == board[2][0] && board [0][2] != 0) {
                    winCondition = true
                    if (board[0][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if (board[0][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }

                }
                if(!winCondition && turns == 9) {
                    println("Draw Game")
                    gameResult.text = "draw"
                    println(gameResult)
                    gameResult.visibility = View.VISIBLE
                    imageWin.setImageResource(R.drawable.blankframe)
                    imageWin.visibility = View.VISIBLE
                }

                if(winCondition) {
                    lockImage = true
                    lockImage2 = true
                    lockImage3 = true
                    lockImage4 = true
                    lockImage5 = true
                    lockImage6 = true
                    lockImage7 = true
                    lockImage8 = true
                    lockImage9 = true
                }
            }
        }

        imageView4.setOnClickListener {
            if (!lockImage4) {
                if (gameTurn == "Cross") {
                    imageView4.setImageResource(R.drawable.crossframe)
                    gameTurn = "Circle"
                    board[1][0] = 1
                } else {
                    imageView4.setImageResource(R.drawable.circleframe)
                    gameTurn = "Cross"
                    board[1][0] = 2
                }
                lockImage4 = true
                turns++
                turnComplete = true
                println("completed turn")
                var i = 0
                while(i < 3) {
                    println("Horizontal Checking")
                    if(board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] != 0) {
                        winCondition = true
                        if(board[i][0] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("horizontal cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[i][1] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("horizontal circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i = 3
                    }else{
                        i++
                    }
                }
                i = 0

                while(i<3) {
                    println("Vertical Checking")
                    if(board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] != 0) {
                        winCondition = true
                        if(board[0][i] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("Vertical Cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[0][i] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("Vertical Circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i=3
                    }else{
                        i++
                    }
                }
                i = 0

                //left cross
                println("Left Cross Checking")
                if (board[0][0] == board[1][1] && board[0][0] == board[2][2] && board [0][0] != 0) {
                    winCondition = true
                    if (board[2][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if(board[2][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                }

                //right cross
                println("Right Cross Checking")
                if (board[0][2] == board[1][1] && board[0][2] == board[2][0] && board [0][2] != 0) {
                    winCondition = true
                    if (board[0][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if (board[0][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                }
                if(!winCondition && turns == 9) {
                    println("Draw Game")
                    gameResult.text = "draw"
                    println(gameResult)
                    gameResult.visibility = View.VISIBLE
                    imageWin.setImageResource(R.drawable.blankframe)
                    imageWin.visibility = View.VISIBLE
                }

                if(winCondition) {
                    lockImage = true
                    lockImage2 = true
                    lockImage3 = true
                    lockImage4 = true
                    lockImage5 = true
                    lockImage6 = true
                    lockImage7 = true
                    lockImage8 = true
                    lockImage9 = true
                }
            }
        }

        imageView5.setOnClickListener {
            if (!lockImage5) {
                if (gameTurn == "Cross") {
                    imageView5.setImageResource(R.drawable.crossframe)
                    gameTurn = "Circle"
                    board[1][1] = 1
                } else {
                    imageView5.setImageResource(R.drawable.circleframe)
                    gameTurn = "Cross"
                    board[1][1] = 2
                }
                lockImage5 = true
                turns++
                turnComplete = true
                println("completed turn")
                var i = 0
                while(i < 3) {
                    println("Horizontal Checking")
                    if(board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] != 0) {
                        winCondition = true
                        if(board[i][0] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("horizontal cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[i][1] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("horizontal circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i = 3
                    }else{
                        i++
                    }
                }
                i = 0

                while(i<3) {
                    println("Vertical Checking")
                    if(board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] != 0) {
                        winCondition = true
                        if(board[0][i] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("Vertical Cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[0][i] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("Vertical Circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i=3
                    }else{
                        i++
                    }
                }
                i = 0

                //left cross
                println("Left Cross Checking")
                if (board[0][0] == board[1][1] && board[0][0] == board[2][2] && board [0][0] != 0) {
                    winCondition = true
                    if (board[2][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if(board[2][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                }

                //right cross
                println("Right Cross Checking")
                if (board[0][2] == board[1][1] && board[0][2] == board[2][0] && board [0][2] != 0) {
                    winCondition = true
                    if (board[0][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if (board[0][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }

                }
                if(!winCondition && turns == 9) {
                    println("Draw Game")
                    gameResult.text = "draw"
                    println(gameResult)
                    gameResult.visibility = View.VISIBLE
                    imageWin.setImageResource(R.drawable.blankframe)
                    imageWin.visibility = View.VISIBLE
                }

                if(winCondition) {
                    lockImage = true
                    lockImage2 = true
                    lockImage3 = true
                    lockImage4 = true
                    lockImage5 = true
                    lockImage6 = true
                    lockImage7 = true
                    lockImage8 = true
                    lockImage9 = true
                }
            }
        }

        imageView6.setOnClickListener {
            if (!lockImage6) {
                if (gameTurn == "Cross") {
                    imageView6.setImageResource(R.drawable.crossframe)
                    gameTurn = "Circle"
                    board[1][2] = 1
                } else {
                    imageView6.setImageResource(R.drawable.circleframe)
                    gameTurn = "Cross"
                    board[1][2] = 2
                }
                lockImage6 = true
                turns++
                turnComplete = true
                println("completed turn")
                var i = 0
                while(i < 3) {
                    println("Horizontal Checking")
                    if(board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] != 0) {
                        winCondition = true
                        if(board[i][0] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("horizontal cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[i][1] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("horizontal circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i = 3
                    }else{
                        i++
                    }
                }
                i = 0

                while(i<3) {
                    println("Vertical Checking")
                    if(board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] != 0) {
                        winCondition = true
                        if(board[0][i] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("Vertical Cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[0][i] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("Vertical Circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i=3
                    }else{
                        i++
                    }
                }
                i = 0

                //left cross
                println("Left Cross Checking")
                if (board[0][0] == board[1][1] && board[0][0] == board[2][2] && board [0][0] != 0) {
                    winCondition = true
                    if (board[2][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if(board[2][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                }

                //right cross
                println("Right Cross Checking")
                if (board[0][2] == board[1][1] && board[0][2] == board[2][0] && board [0][2] != 0) {
                    winCondition = true
                    if (board[0][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if (board[0][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }

                }
                if(!winCondition && turns == 9) {
                    println("Draw Game")
                    gameResult.text = "draw"
                    println(gameResult)
                    gameResult.visibility = View.VISIBLE
                    imageWin.setImageResource(R.drawable.blankframe)
                    imageWin.visibility = View.VISIBLE
                }

                if(winCondition) {
                    lockImage = true
                    lockImage2 = true
                    lockImage3 = true
                    lockImage4 = true
                    lockImage5 = true
                    lockImage6 = true
                    lockImage7 = true
                    lockImage8 = true
                    lockImage9 = true
                }
            }
        }

        imageView7.setOnClickListener {
            if (!lockImage7) {
                if (gameTurn == "Cross") {
                    imageView7.setImageResource(R.drawable.crossframe)
                    gameTurn = "Circle"
                    board[2][0] = 1
                } else {
                    imageView7.setImageResource(R.drawable.circleframe)
                    gameTurn = "Cross"
                    board[2][0] = 2
                }
                lockImage7 = true
                turns++
                turnComplete = true
                println("completed turn")
                var i = 0
                while(i < 3) {
                    println("Horizontal Checking")
                    if(board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] != 0) {
                        winCondition = true
                        if(board[i][0] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("horizontal cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[i][1] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("horizontal circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i = 3
                    }else{
                        i++
                    }
                }
                i = 0

                while(i<3) {
                    println("Vertical Checking")
                    if(board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] != 0) {
                        winCondition = true
                        if(board[0][i] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("Vertical Cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[0][i] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("Vertical Circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i=3
                    }else{
                        i++
                    }
                }
                i = 0

                //left cross
                println("Left Cross Checking")
                if (board[0][0] == board[1][1] && board[0][0] == board[2][2] && board [0][0] != 0) {
                    winCondition = true
                    if (board[2][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if(board[2][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                }

                //right cross
                println("Right Cross Checking")
                if (board[0][2] == board[1][1] && board[0][2] == board[2][0] && board [0][2] != 0) {
                    winCondition = true
                    if (board[0][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if (board[0][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }

                }
                if(!winCondition && turns == 9) {
                    println("Draw Game")
                    gameResult.text = "draw"
                    println(gameResult)
                    gameResult.visibility = View.VISIBLE
                    imageWin.setImageResource(R.drawable.blankframe)
                    imageWin.visibility = View.VISIBLE
                }

                if(winCondition) {
                    lockImage = true
                    lockImage2 = true
                    lockImage3 = true
                    lockImage4 = true
                    lockImage5 = true
                    lockImage6 = true
                    lockImage7 = true
                    lockImage8 = true
                    lockImage9 = true
                }
            }
        }

        imageView8.setOnClickListener {
            if (!lockImage8) {
                if (gameTurn == "Cross") {
                    imageView8.setImageResource(R.drawable.crossframe)
                    gameTurn = "Circle"
                    board[2][1] = 1
                } else {
                    imageView8.setImageResource(R.drawable.circleframe)
                    gameTurn = "Cross"
                    board[2][1] = 2
                }
                lockImage8 = true
                turns++
                turnComplete = true
                println("completed turn")
                var i = 0
                while(i < 3) {
                    println("Horizontal Checking")
                    if(board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] != 0) {
                        winCondition = true
                        if(board[i][0] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("horizontal cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[i][1] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("horizontal circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i = 3
                    }else{
                        i++
                    }
                }
                i = 0

                while(i<3) {
                    println("Vertical Checking")
                    if(board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] != 0) {
                        winCondition = true
                        if(board[0][i] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("Vertical Cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[0][i] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("Vertical Circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i=3
                    }else{
                        i++
                    }
                }
                i = 0

                //left cross
                println("Left Cross Checking")
                if (board[0][0] == board[1][1] && board[0][0] == board[2][2] && board [0][0] != 0) {
                    winCondition = true
                    if (board[2][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if(board[2][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                }

                //right cross
                println("Right Cross Checking")
                if (board[0][2] == board[1][1] && board[0][2] == board[2][0] && board [0][2] != 0) {
                    winCondition = true
                    if (board[0][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if (board[0][2] == 2) {
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }

                }
                if(!winCondition && turns == 9) {
                    println("Draw Game")
                    gameResult.text = "draw"
                    println(gameResult)
                    gameResult.visibility = View.VISIBLE
                    imageWin.setImageResource(R.drawable.blankframe)
                    imageWin.visibility = View.VISIBLE
                }

                if(winCondition) {
                    lockImage = true
                    lockImage2 = true
                    lockImage3 = true
                    lockImage4 = true
                    lockImage5 = true
                    lockImage6 = true
                    lockImage7 = true
                    lockImage8 = true
                    lockImage9 = true
                }
            }
        }

        imageView9.setOnClickListener {
            if (!lockImage9) {
                if (gameTurn == "Cross") {
                    imageView9.setImageResource(R.drawable.crossframe)
                    gameTurn = "Circle"
                    board[2][2] = 1
                } else {
                    imageView9.setImageResource(R.drawable.circleframe)
                    gameTurn = "Cross"
                    board[2][2] = 2
                }
                lockImage9 = true
                turns++
                turnComplete = true
                println("completed turn")
                var i = 0
                while(i < 3) {
                    println("Horizontal Checking")
                    if(board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] != 0) {
                        winCondition = true
                        if(board[i][0] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("horizontal cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[i][1] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("horizontal circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i = 3
                    }else{
                        i++
                    }
                }
                i = 0

                while(i<3) {
                    println("Vertical Checking")
                    if(board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] != 0) {
                        winCondition = true
                        if(board[0][i] == 1) {
                            gameResult.text = "Cross Wins"
                            imageWin.setImageResource(R.drawable.crossframe)
                            println("Vertical Cross")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        if(board[0][i] == 2) {
                            gameResult.text = "Circle Wins"
                            imageWin.setImageResource(R.drawable.circleframe)
                            println("Vertical Circle")
                            gameResult.visibility = View.VISIBLE
                            imageWin.visibility = View.VISIBLE
                        }
                        i=3
                    }else{
                        i++
                    }
                }
                i = 0

                //left cross
                println("Left Cross Checking")
                if (board[0][0] == board[1][1] && board[0][0] == board[2][2] && board [0][0] != 0) {
                    winCondition = true
                    if (board[2][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if(board[2][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                }

                //right cross
                println("Right Cross Checking")
                if (board[0][2] == board[1][1] && board[0][2] == board[2][0] && board [0][2] != 0) {
                    winCondition = true
                    if (board[0][2] == 1) {
                        imageWin.setImageResource(R.drawable.crossframe)
                        gameResult.text = "Cross Wins"
                        println("Cross Cross")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }
                    if (board[0][2] == 2){
                        imageWin.setImageResource(R.drawable.circleframe)
                        gameResult.text = "Circle Wins"
                        println("Cross Circle")
                        gameResult.visibility = View.VISIBLE
                        imageWin.visibility = View.VISIBLE
                    }

                }
                if(!winCondition && turns == 9) {
                    println("Draw Game")
                    gameResult.text = "draw"
                    println(gameResult)
                    gameResult.visibility = View.VISIBLE
                    imageWin.setImageResource(R.drawable.blankframe)
                    imageWin.visibility = View.VISIBLE
                }

                if(winCondition) {
                    lockImage = true
                    lockImage2 = true
                    lockImage3 = true
                    lockImage4 = true
                    lockImage5 = true
                    lockImage6 = true
                    lockImage7 = true
                    lockImage8 = true
                    lockImage9 = true
                }
            }
        }

        resetButton.setOnClickListener {
            imageView.setImageResource(R.drawable.blankframe)
            imageView2.setImageResource(R.drawable.blankframe)
            imageView3.setImageResource(R.drawable.blankframe)
            imageView4.setImageResource(R.drawable.blankframe)
            imageView5.setImageResource(R.drawable.blankframe)
            imageView6.setImageResource(R.drawable.blankframe)
            imageView7.setImageResource(R.drawable.blankframe)
            imageView8.setImageResource(R.drawable.blankframe)
            imageView9.setImageResource(R.drawable.blankframe)
            gameTurn = "Cross"
            println(turns)
            turns = 0
            winCondition = false
            gameResult.visibility = View.INVISIBLE
            imageWin.visibility = View.INVISIBLE
            lockImage = false
            lockImage2 = false
            lockImage3 = false
            lockImage4 = false
            lockImage5 = false
            lockImage6 = false
            lockImage7 = false
            lockImage8 = false
            lockImage9 = false
            var i = 0
            while(i<3) {
                board[0][i] = 0
                board[1][i] = 0
                board[2][i] = 0
                i++
            }
        }


    }
}